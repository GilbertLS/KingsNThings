package Game.Networking;

public class Protocol {
	public static String HOSTSERVER = "HostServer";
	public static String GETHOSTEDSERVERS = "GetHostedServers";
	public static String JOINSERVER = "JoinServer";
	public static String EXIT = "-1";
	public static String DELIMITER = " ";
	public static String FOUND = "Found";
	public static String NOTFOUND = "NotFound";
	public static int GAMEPORT = 5003;
}
