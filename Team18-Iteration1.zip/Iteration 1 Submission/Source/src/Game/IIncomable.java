package Game;

/*
 * This interface provides the methods required for an object to generate income
 */
public interface IIncomable {
	public int getIncome();
}
