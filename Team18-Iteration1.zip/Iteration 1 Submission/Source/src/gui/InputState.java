package gui;

public enum InputState {
	NOT_WAITING_FOR_INPUT,
	WAITING_FOR_INPUT,
	GOT_INPUT
}
